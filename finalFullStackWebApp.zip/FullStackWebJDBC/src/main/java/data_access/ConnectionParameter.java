package data_access;

public class ConnectionParameter {
	public static final String jdbcDriver = "org.sqlite.JDBC";
	public static final String databasefolder = "/C:\\Users\\Quan Doan\\Desktop\\Haaga-java\\Programming2/FullStackWebJDBC/src/main/java/database/studentdatabase.db";
	public static final String driverConnection = "jdbc:sqlite:" + databasefolder;
}
